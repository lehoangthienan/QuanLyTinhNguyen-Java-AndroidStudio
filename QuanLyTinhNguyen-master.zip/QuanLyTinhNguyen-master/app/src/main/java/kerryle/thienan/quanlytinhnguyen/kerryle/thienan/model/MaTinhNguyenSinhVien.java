package kerryle.thienan.quanlytinhnguyen.kerryle.thienan.model;

/**
 * Created by Thien An on 2017-12-24.
 */

public class MaTinhNguyenSinhVien {
    private String MATN;

    public MaTinhNguyenSinhVien(String MATN) {
        this.MATN = MATN;
    }

    public void setMATN(String MATN) {
        this.MATN = MATN;
    }

    public String getMATN() {
        return MATN;
    }
}
