package kerryle.thienan.quanlytinhnguyen.kerryle.thienan.model;

/**
 * Created by Thien An on 2017-12-16.
 */

public class SoHoatDongThamGia {
    private String SOLUONG;

    public String getSOLUONG() {
        return SOLUONG;
    }

    public void setSOLUONG(String SOLUONG) {
        this.SOLUONG = SOLUONG;
    }

    public SoHoatDongThamGia() {
    }

    public SoHoatDongThamGia(String SOLUONG) {
        this.SOLUONG = SOLUONG;
    }
}
