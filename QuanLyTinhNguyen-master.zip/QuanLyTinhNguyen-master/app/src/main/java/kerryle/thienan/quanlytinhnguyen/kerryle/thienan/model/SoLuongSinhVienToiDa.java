package kerryle.thienan.quanlytinhnguyen.kerryle.thienan.model;

/**
 * Created by Thien An on 2017-12-26.
 */

public class SoLuongSinhVienToiDa {
    int SLMax;

    public SoLuongSinhVienToiDa(int SLMax) {
        this.SLMax = SLMax;
    }

    public void setSLMax(int SLMax) {
        this.SLMax = SLMax;
    }

    public int getSLMax() {
        return SLMax;
    }
}
