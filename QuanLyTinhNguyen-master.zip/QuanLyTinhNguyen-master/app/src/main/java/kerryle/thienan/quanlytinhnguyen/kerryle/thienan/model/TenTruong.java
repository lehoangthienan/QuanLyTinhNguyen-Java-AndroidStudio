package kerryle.thienan.quanlytinhnguyen.kerryle.thienan.model;

/**
 * Created by Thien An on 2017-12-20.
 */

public class TenTruong {
    private  String TenTruong;

    public TenTruong(String tenTruong) {
        TenTruong = tenTruong;
    }

    public void setTenTruong(String tenTruong) {
        TenTruong = tenTruong;
    }

    public String getTenTruong() {
        return TenTruong;
    }
}
